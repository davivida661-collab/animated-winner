package me.peanut.hydrogen.utils;

import org.apache.commons.lang3.RandomUtils;

public class TimeUtils {
    // Static lastMS is shared across all instances — used only by the static API (SprintReset, etc.)
    // Do NOT use static lastMS from instance methods; use instanceLastMS instead.
    private static long staticLastMS = 0L;
    private long instanceLastMS = 0L;
    private long resetMS = 0L;

    public static long randomDelay(final int minDelay, final int maxDelay) {
        if (minDelay >= maxDelay) return minDelay;
        return RandomUtils.nextInt(minDelay, maxDelay);
    }

    public static long getCurrentMS() {
        return System.nanoTime() / 1000000L;
    }

    public static long getCurrentTime() {
        return (long) (System.nanoTime() / 1000000.0D);
    }

    /** Instance method — uses per-instance lastMS. Safe for concurrent modules. */
    public boolean isDelayComplete(long delay) {
        return getCurrentMS() - instanceLastMS >= delay;
    }

    public boolean hasDelayRun(double d) {
        return System.currentTimeMillis() >= this.resetMS + d;
    }

    public static boolean hasTimePassedMS(long lastMS, long MS) {
        return (getCurrentMS() >= lastMS + MS);
    }

    /** Static overload — uses shared staticLastMS. Only for callers that also call reset(). */
    public static boolean hasTimePassedMS(long MS) {
        return (getCurrentMS() >= staticLastMS + MS);
    }

    public void resetAndAdd(long reset) {
        this.resetMS = (getCurrentTime() + reset);
    }

    /** Instance method — uses per-instance lastMS. */
    public boolean hasReached(long milliseconds) {
        return getCurrentMS() - instanceLastMS >= milliseconds;
    }

    /** Resets shared static timer. Pairs with the static hasTimePassedMS(long). */
    public static void reset() {
        staticLastMS = getCurrentMS();
    }

    /** Sets this instance's lastMS. Use this from instance contexts. */
    public void setLastMS() {
        instanceLastMS = System.currentTimeMillis();
    }

}