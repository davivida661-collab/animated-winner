package me.peanut.hydrogen.ui.clickgui.component.components.sub;

import java.awt.*;
import java.math.BigDecimal;
import java.math.RoundingMode;

import me.peanut.hydrogen.font.FontHelper;
import me.peanut.hydrogen.utils.RenderUtil;
import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import me.peanut.hydrogen.Hydrogen;
import me.peanut.hydrogen.ui.clickgui.component.Component;
import me.peanut.hydrogen.ui.clickgui.component.components.Button;
import me.peanut.hydrogen.settings.Setting;
import me.peanut.hydrogen.module.modules.gui.ClickGUI;
import me.peanut.hydrogen.module.Module;

public class SliderButton extends Component {

	private boolean hovered;
	private final Setting set;
	private final Button parent;
	private int offset;
	private int x;
	private int y;
	private boolean dragging = false;
	private double renderWidth;

	public SliderButton(Setting value, Button button, int offset) {
		this.set = value;
		this.parent = button;
		this.x = button.parent.getX() + button.parent.getWidth();
		this.y = button.parent.getY() + button.offset;
		this.offset = offset;
	}

	private Color getAccentColor() {
		Module cgui = Hydrogen.getClient().moduleManager.getModule(ClickGUI.class);
		return new Color(
			(int) Hydrogen.getClient().settingsManager.getSettingByName(cgui, "Red").getValue(),
			(int) Hydrogen.getClient().settingsManager.getSettingByName(cgui, "Green").getValue(),
			(int) Hydrogen.getClient().settingsManager.getSettingByName(cgui, "Blue").getValue(),
			Math.min(255, (int) Hydrogen.getClient().settingsManager.getSettingByName(cgui, "Alpha").getValue() + 60)
		);
	}

	@Override
	public void renderComponent() {
		Color accent = getAccentColor();
		int frameX = parent.parent.getX();
		int frameW = parent.parent.getWidth();
		int baseY = parent.parent.getY() + offset;

		// Track background
		RenderUtil.rect(frameX + 1, baseY, frameX + frameW, baseY + 12, hovered ? 0xBB0D0F12 : 0xAA0D0F12);

		// Filled portion — clamped to track width
		int fillW = (int) Math.min(renderWidth, frameW - 1);
		if (fillW > 0) {
			// Accent fill with slight transparency
			Color fillColor = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 140);
			RenderUtil.rect(frameX + 1, baseY, frameX + 1 + fillW, baseY + 12, fillColor.getRGB());
		}

		// Drag handle — 2px vertical bar at fill edge
		if (fillW > 0) {
			RenderUtil.rect(frameX + 1 + fillW - 1, baseY + 1, frameX + 1 + fillW + 1, baseY + 11, 0xFFFFFFFF);
		}

		// Left indent accent
		RenderUtil.rect(frameX, baseY, frameX + 1, baseY + 12, accent.getRGB());

		// Name and value labels at 0.75 scale
		GL11.glPushMatrix();
		GL11.glScalef(0.75f, 0.75f, 0.75f);

		boolean ttf = Hydrogen.getClient().settingsManager.getSettingByName("Font Type").getMode().equalsIgnoreCase("TTF");
		String nameStr  = hovered ? "§7" + this.set.getName() : this.set.getName();
		String valueStr = String.valueOf(this.set.getValue());

		float labelY = (parent.parent.getY() + offset + 2) * 1.3333f;
		if (ttf) {
			FontHelper.verdana.drawStringWithShadow(nameStr, frameX * 1.3333f + 8, labelY, Color.white);
			FontHelper.verdana.drawStringWithShadow(valueStr, (frameX + frameW - 2) * 1.3333f - FontHelper.verdana.getStringWidth(valueStr), labelY, Color.white);
		} else {
			Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(nameStr, frameX * 1.3333f + 8, labelY + 2, -1);
			Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(valueStr, (frameX + frameW - 2) * 1.3333f - Minecraft.getMinecraft().fontRendererObj.getStringWidth(valueStr), labelY + 2, -1);
		}

		GL11.glPopMatrix();
	}

	@Override
	public void setOff(int newOff) {
		offset = newOff;
	}

	@Override
	public void updateComponent(int mouseX, int mouseY) {
		this.hovered = isMouseOnButton(mouseX, mouseY);
		this.y = parent.parent.getY() + offset;
		this.x = parent.parent.getX();

		double min = set.getMin();
		double max = set.getMax();
		int trackW = parent.parent.getWidth() - 1;

		// renderWidth: pixel fill based on current value in [min, max]
		renderWidth = trackW * (set.getValue() - min) / (max - min);
		renderWidth = Math.max(0, Math.min(trackW, renderWidth));

		if (dragging) {
			double mouseRelative = Math.min(trackW, Math.max(0, mouseX - this.x - 1));
			double newValue = roundToPlace(mouseRelative / trackW * (max - min) + min, 2);
			newValue = Math.max(min, Math.min(max, newValue));
			set.setValue(newValue);
		}
	}

	private static double roundToPlace(double value, int places) {
		if (places < 0) throw new IllegalArgumentException();
		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}

	@Override
	public void mouseClicked(int mouseX, int mouseY, int button) {
		if (isMouseOnButton(mouseX, mouseY) && button == 0 && this.parent.open) {
			dragging = true;
		}
	}

	@Override
	public void mouseReleased(int mouseX, int mouseY, int mouseButton) {
		dragging = false;
	}

	public boolean isMouseOnButton(int x, int y) {
		return x > this.x && x < this.x + parent.parent.getWidth() && y > this.y && y < this.y + 12;
	}
}
