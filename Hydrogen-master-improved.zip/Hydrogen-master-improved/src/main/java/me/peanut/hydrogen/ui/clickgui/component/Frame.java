package me.peanut.hydrogen.ui.clickgui.component;

import java.awt.*;
import java.util.ArrayList;

import me.peanut.hydrogen.module.Category;
import me.peanut.hydrogen.module.Module;
import me.peanut.hydrogen.ui.clickgui.component.components.Button;
import me.peanut.hydrogen.font.FontUtil;
import me.peanut.hydrogen.utils.RenderUtil;
import net.minecraft.client.gui.FontRenderer;
import me.peanut.hydrogen.Hydrogen;
import me.peanut.hydrogen.module.modules.gui.ClickGUI;

public class Frame {

	public final ArrayList<Component> components;
	public final Category category;
	public boolean open;
	public final int width;
	public int y;
	public int x;
	public final int barHeight;
	private boolean isDragging;
	public int dragX;
	public int dragY;

	public Frame(Category cat) {
		this.components = new ArrayList<>();
		this.category = cat;
		this.width = 92;
		this.x = 5;
		this.y = 5;
		this.barHeight = 14;
		this.dragX = 0;
		this.open = false;
		this.isDragging = false;
		int tY = this.barHeight;

		for (Module mod : Hydrogen.getClient().moduleManager.getModulesInCategory(category)) {
			Button modButton = new Button(mod, this, tY);
			this.components.add(modButton);
			tY += 12;
		}
	}

	public ArrayList<Component> getComponents() {
		return components;
	}

	public void setX(int newX) {
		this.x = newX;
	}

	public void setY(int newY) {
		this.y = newY;
	}

	public void setDrag(boolean drag) {
		this.isDragging = drag;
	}

	public boolean isOpen() {
		return open;
	}

	public void setOpen(boolean open) {
		this.open = open;
	}

	public void renderFrame(FontRenderer fontRenderer) {
		Module cgui = Hydrogen.getClient().moduleManager.getModule(ClickGUI.class);
		Color accentColor = new Color(
			(int) Hydrogen.getClient().settingsManager.getSettingByName(cgui, "Red").getValue(),
			(int) Hydrogen.getClient().settingsManager.getSettingByName(cgui, "Green").getValue(),
			(int) Hydrogen.getClient().settingsManager.getSettingByName(cgui, "Blue").getValue(),
			(int) Hydrogen.getClient().settingsManager.getSettingByName(cgui, "Alpha").getValue()
		);
		int accentRGB = accentColor.getRGB();

		// Drop shadow — 1px underlay gives depth
		RenderUtil.rect(this.x - 1, this.y - 1, this.x + this.width + 2, this.y + this.barHeight + 1, 0x55000000);

		// Header panel — dark opaque base
		RenderUtil.rect(this.x, this.y, this.x + this.width, this.y + this.barHeight, 0xEE101318);

		// Accent bar — 2px bottom strip in theme color
		RenderUtil.rect(this.x, this.y + this.barHeight - 2, this.x + this.width, this.y + this.barHeight, accentRGB);

		// Body background + left accent rail when open
		if (this.open && !this.components.isEmpty()) {
			int totalHeight = 0;
			for (Component c : this.components) totalHeight += c.getHeight();
			RenderUtil.rect(this.x, this.y + this.barHeight, this.x + this.width, this.y + this.barHeight + totalHeight, 0xCC0D0F12);
			// Left 1px accent rail
			RenderUtil.rect(this.x, this.y + this.barHeight, this.x + 1, this.y + this.barHeight + totalHeight, accentRGB);
			// Bottom cap line
			RenderUtil.rect(this.x, this.y + this.barHeight + totalHeight, this.x + this.width, this.y + this.barHeight + totalHeight + 1, 0xAA101318);
		}

		// Category label
		if (Hydrogen.getClient().settingsManager.getSettingByName("Font Type").getMode().equalsIgnoreCase("TTF")) {
			FontUtil.drawTotalCenteredStringWithShadowVerdana(this.category.name(), (this.x + this.width / 2), (this.y + 7) - 3, Color.white);
		} else {
			FontUtil.drawTotalCenteredStringWithShadowMC(this.category.name(), (this.x + this.width / 2), (this.y + 7) - 1, -1);
		}

		// Collapse arrow — accent colored, right-aligned
		String arrow = this.open ? "-" : "+";
		fontRenderer.drawStringWithShadow(arrow, this.x + this.width - 9, this.y + 3, accentRGB);

		for (Component component : this.components) {
			if (this.open && !this.components.isEmpty()) {
				component.renderComponent();
			}
		}
	}

	public void refresh() {
		int off = this.barHeight;
		for (Component comp : components) {
			comp.setOff(off);
			off += comp.getHeight();
		}
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getWidth() {
		return width;
	}

	public void updatePosition(int mouseX, int mouseY) {
		if (this.isDragging) {
			this.setX(mouseX - dragX);
			this.setY(mouseY - dragY);
		}
	}

	public boolean isWithinHeader(int x, int y) {
		return x >= this.x && x <= this.x + this.width && y >= this.y && y <= this.y + this.barHeight;
	}
}
