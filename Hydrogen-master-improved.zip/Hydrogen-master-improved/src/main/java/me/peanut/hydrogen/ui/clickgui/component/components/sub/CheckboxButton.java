package me.peanut.hydrogen.ui.clickgui.component.components.sub;

import me.peanut.hydrogen.font.FontHelper;
import me.peanut.hydrogen.utils.RenderUtil;
import me.peanut.hydrogen.module.modules.gui.ClickGUI;
import me.peanut.hydrogen.module.Module;
import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import me.peanut.hydrogen.Hydrogen;
import me.peanut.hydrogen.ui.clickgui.component.Component;
import me.peanut.hydrogen.ui.clickgui.component.components.Button;
import me.peanut.hydrogen.settings.Setting;

import java.awt.*;

public class CheckboxButton extends Component {

	private boolean hovered;
	private final Setting op;
	private final Button parent;
	private int offset;
	private int x;
	private int y;

	public CheckboxButton(Setting option, Button button, int offset) {
		this.op = option;
		this.parent = button;
		this.x = button.parent.getX() + button.parent.getWidth();
		this.y = button.parent.getY() + button.offset;
		this.offset = offset;
	}

	private Color getAccentColor() {
		Module cgui = Hydrogen.getClient().moduleManager.getModule(ClickGUI.class);
		return new Color(
			(int) Hydrogen.getClient().settingsManager.getSettingByName(cgui, "Red").getValue(),
			(int) Hydrogen.getClient().settingsManager.getSettingByName(cgui, "Green").getValue(),
			(int) Hydrogen.getClient().settingsManager.getSettingByName(cgui, "Blue").getValue(),
			(int) Hydrogen.getClient().settingsManager.getSettingByName(cgui, "Alpha").getValue()
		);
	}

	@Override
	public void renderComponent() {
		Color accent = getAccentColor();
		int frameX = parent.parent.getX();
		int frameW = parent.parent.getWidth();
		int baseY  = parent.parent.getY() + offset;

		// Row background
		Gui.drawRect(frameX + 1, baseY, frameX + frameW, baseY + 12, hovered ? 0xBB0D0F12 : 0xAA0D0F12);

		// Left indent accent
		RenderUtil.rect(frameX, baseY, frameX + 1, baseY + 12, accent.getRGB());

		// Setting name — scaled 0.75x
		GL11.glPushMatrix();
		GL11.glScalef(0.75f, 0.75f, 0.75f);
		String label = hovered ? "§7" + this.op.getName() : this.op.getName();
		boolean ttf = Hydrogen.getClient().settingsManager.getSettingByName("Font Type").getMode().equalsIgnoreCase("TTF");
		float labelX = (frameX + 3) * 1.3333f + 5;
		float labelY = (baseY + 2) * 1.3333f;
		if (ttf) {
			FontHelper.verdana.drawStringWithShadow(label, labelX, labelY, Color.white);
		} else {
			Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(label, labelX, labelY + 2, -1);
		}
		GL11.glPopMatrix();

		// Checkbox box — right side, 7x6 px
		int boxX1 = frameX + frameW - 9;
		int boxX2 = frameX + frameW - 2;
		int boxY1 = baseY + 3;
		int boxY2 = baseY + 9;

		// Box border — accent when enabled, gray when disabled
		int borderColor = op.isEnabled() ? accent.getRGB() : 0x88999999;
		Gui.drawRect(boxX1 - 1, boxY1 - 1, boxX2 + 1, boxY2 + 1, 0x55000000); // shadow
		Gui.drawRect(boxX1, boxY1, boxX2, boxY2, borderColor);

		// Inner fill
		if (op.isEnabled()) {
			// Filled: accent tint inside
			Color fillColor = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 200);
			Gui.drawRect(boxX1 + 1, boxY1 + 1, boxX2 - 1, boxY2 - 1, fillColor.getRGB());
		} else {
			// Empty: dark void
			Gui.drawRect(boxX1 + 1, boxY1 + 1, boxX2 - 1, boxY2 - 1, 0x99000000);
		}
	}

	@Override
	public void setOff(int newOff) {
		offset = newOff;
	}

	@Override
	public void updateComponent(int mouseX, int mouseY) {
		this.hovered = isMouseOnButton(mouseX, mouseY);
		this.y = parent.parent.getY() + offset;
		this.x = parent.parent.getX();
	}

	@Override
	public void mouseClicked(int mouseX, int mouseY, int button) {
		if (isMouseOnButton(mouseX, mouseY) && button == 0 && this.parent.open) {
			this.op.setState(!op.isEnabled());
		}
	}

	public boolean isMouseOnButton(int x, int y) {
		return x > this.x && x < this.x + 88 && y > this.y && y < this.y + 12;
	}
}
